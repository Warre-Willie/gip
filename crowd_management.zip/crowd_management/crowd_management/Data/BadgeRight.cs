﻿
namespace crowd_management.Data
{
	public class BadgeRight
	{
		public string Name { get; set; }

		public bool Value { get; set; }
	}
}