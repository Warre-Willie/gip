﻿

using System.Collections.Generic;

namespace crowd_management.Data
{
	public class Zone
	{
		public string Name { get; set; }
		public string ThresholdGreen { get; set; }
		public string ThresholdOrange { get; set; }
		public string ThresholdRed { get; set; }
		public string PeopleCount { get; set; }
		public bool BarometerLock { get; set; }
		public string BarometerColor { get; set; }
		public bool AccessLock { get; set; }
		public bool HasPeople => string.IsNullOrEmpty(PeopleCount);

		public List<BadgeRight> Rights =>
			new List<BadgeRight>
			{
				new BadgeRight
				{
					Name = "kamping"
				},
				new BadgeRight
				{
					Name = "VIP"
				},
				new BadgeRight
				{
					Name = "backstage"
				},
				new BadgeRight
				{
					Name = "artiest"
				},
			};

		public string GetColorClass()
		{
			switch (BarometerColor)
			{
				case "green":
					return "success";
				case "orange":
					return "warning";
				case "red":
					return "danger";
			}

			return string.Empty;
		}
	}
}