﻿
using MySql.Data.MySqlClient;
using System;

namespace crowd_management.Data
{
	public class Repository
	{
		const string constring = "SERVER=localhost;DATABASE=crowd_management;UID=root;PASSWORD=gip-WJ;";

		MySqlConnection conn = new MySqlConnection(constring);

		public Zone GetZone(object zoneId)
		{
			Zone zone = null;

			string query = $"SELECT * FROM zones WHERE id='{zoneId}';";
			conn.Open();
			MySqlCommand cmd = new MySqlCommand(query, conn);
			MySqlDataReader reader = cmd.ExecuteReader();

			// Check firt if zone exist if not show messages
			if (reader.HasRows)
			{
				zone = new Zone();
				while (reader.Read())
				{
					zone.Name = zone.Name;
					zone.ThresholdGreen = reader["threshold_green"].ToString();
					zone.ThresholdOrange = reader["threshold_orange"].ToString();
					zone.ThresholdRed = reader["threshold_red"].ToString();
					zone.PeopleCount = reader["people_count"].ToString();
					zone.BarometerLock = Convert.ToBoolean(reader["barometer_lock"].ToString());
					zone.BarometerColor = reader["barometer_color"].ToString();
					zone.AccessLock = Convert.ToBoolean(reader["access_lock"].ToString());
					foreach (BadgeRight right in zone.Rights)
					{
						right.Value = Convert.ToBoolean(reader[right.Name].ToString());
					}
				}
			}

			conn.Close();

			return zone;
		}

		public void UpdateZone(Zone zone)
		{
			// Code to update zone data
		}

		public DateTime LatestLogTime(object zoneId)
		{
			return DateTime.Now;
		}
	}
}