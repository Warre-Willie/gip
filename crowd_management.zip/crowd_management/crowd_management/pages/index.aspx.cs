﻿using MySql.Data.MySqlClient;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using crowd_management.Data;

namespace crowd_management.pages
{
	public partial class index : Page
	{
		// Database connection should go in another file for all the pages
		private const string conString = "SERVER=localhost;DATABASE=crowd_management;UID=root;PASSWORD=gip-WJ;";
		private const string activeZoneType = "activeZoneType";
		private const string accessZoneType = "access";
		private const string countZoneType = "count";
		MySqlConnection conn = new MySqlConnection(conString);

		public string[] badgeRights = { "kamping", "VIP", "backstage", "artiest" };

		public index()
		{

		}

		protected void Page_Load(object sender, EventArgs e)
		{

		}

		private void LoadZonePanel()
		{
			var repo = new Repository();
			try
			{
				var zone = repo.GetZone(Session["activeZoneID"]);

				// Check firt if zone exist if not show messages
				if (zone != null)
				{
					SetZoneTitle(zone);

					Session[activeZoneType] = accessZoneType;
					SetCardsVisibility(Session[activeZoneType]);

					if (zone.HasPeople)
					{
						cbAccessLock.Checked = zone.AccessLock;
						SetBarRights(zone);
					}
					else
					{
						SetCountLevels(zone);
						SetStatusColor(zone);
					}
				}
				else
				{
					// Message: zone not found
				}
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}

			// Logbook
			try
			{
				// Check if zone type is 'count' and load logbook if not show messages
				if (Session[activeZoneType].ToString() == countZoneType)
				{
					// Get latest timestamp from db
					var nextTimestamp = repo.LatestLogTime(Session["activeZoneID"]);

					string query = $"SELECT MAX(timestamp) AS latestTimeStamp FROM zone_population_data WHERE zone_id = '{Session["activeZoneID"]}'";
					conn.Open();
					MySqlCommand cmd = new MySqlCommand(query, conn);
					MySqlDataReader reader = cmd.ExecuteReader();

					nextTimestamp = DateTime.Now;
					while (reader.Read())
					{
						nextTimestamp = DateTime.Parse(reader["latestTimeStamp"].ToString());
					}

					// Get logbook from db
					query = $"SELECT * FROM zone_population_data WHERE zone_id = '{Session["activeZoneID"]}' ORDER BY timestamp DESC;";

					cmd.CommandText = query;
					reader = cmd.ExecuteReader();

					if (reader.HasRows)
					{
						tbodyLogbook.InnerHtml = "";
						while (reader.Read())
						{
							// Check if currentTimestamp is equale to the nextTimestamp
							DateTime currentTimestamp = DateTime.Parse(reader["timestamp"].ToString());
							if (ignoreSeconds(nextTimestamp) == ignoreSeconds(currentTimestamp))
							{
								tbodyLogbook.InnerHtml += $"<tr><td>{currentTimestamp.ToString("MM-dd HH:mm")}</td><td>{reader["people_count"]}</td></tr>";

								// Update nextTimestamp by distracting the time interval from the currentTimeStamp
								nextTimestamp = currentTimestamp.AddMinutes(-Convert.ToInt16(dbZoneLogbookFilter.SelectedValue));
							}
						}
					}
					else
					{
						// Message: no log book yet
					}
					conn.Close();
				}
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}
		}

		private void SetBarRights(Zone zone)
		{
			foreach (var right in zone.Rights)
			{
				Control tr = FindControl("br" + right.Name);
				tr.Visible = right.Value;

				CheckBox checkBox = (CheckBox) FindControl("cb" + right.Name);
				checkBox.Checked = right.Value;
			}
		}

		private void SetCardsVisibility(object zoneType)
		{
			bool isCountType = zoneType.ToString() == countZoneType;
			divInfoZoneCardsCount.Visible = isCountType;
			divSettingsZoneCardsCount.Visible = isCountType;
			divInfoZoneCardsAccess.Visible = !isCountType;
			divSettingsZoneCardsAccess.Visible = !isCountType;
		}

		private void SetStatusColor(Zone zone)
		{
			// Get color for barometer tag
			string colorClass = zone.GetColorClass();

			tagCurrentStatus.Attributes["class"] = $"tag is-{colorClass} is-light";
			tagCurrentStatusSettings.Attributes["class"] = $"tag is-{colorClass} is-light";
		}

		private void SetCountLevels(Zone zone)
		{
			// Fill zone data from db in
			tbBarThresGreen.Text = zone.ThresholdGreen;
			tbBarThresOrange.Text = zone.ThresholdOrange;
			tbBarThresRed.Text = zone.ThresholdRed;

			tbEditPeopleCount.Text = zone.PeopleCount;

			cbBarLock.Checked = zone.BarometerLock;
		}

		private void SetZoneTitle(Zone zone)
		{
			spanZoneName.InnerHtml = $"<b>{zone.Name}</b> info";
			spanZoneNameSettings.InnerHtml = $"<b>{zone.Name}</b> instellingen";

			// Fill zone data from db in
			tbZoneName.Text = zone.Name;
		}

		static DateTime ignoreSeconds(DateTime dateTime)
		{
			return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, dateTime.Hour, dateTime.Minute, 0, 0);
		}

		protected void imgHeatMap_Click(object sender, ImageMapEventArgs e)
		{
			// Only execute this if column is disabled
			if (divInfoPanel.Attributes["class"].IndexOf("column-disabled") != -1)
			{
				divInfoPanel.Attributes["class"] = divInfoPanel.Attributes["class"].Replace(" column-disabled", "");
				btnZoneSettings.Attributes["class"] = btnZoneSettings.Attributes["class"].Replace("is-static", "");

				btnBarManGreen.Attributes["class"] = btnBarManGreen.Attributes["class"].Replace(" is-static", "");
				btnBarManOrange.Attributes["class"] = btnBarManOrange.Attributes["class"].Replace(" is-static", "");
				btnBarManRed.Attributes["class"] = btnBarManRed.Attributes["class"].Replace(" is-static", "");
			}

			Session["activeZoneID"] = e.PostBackValue.ToString();
			LoadZonePanel();
		}

		protected void btnSaveZoneSettings_Click(object sender, EventArgs e)
		{
			string query = "";
			if (Session[activeZoneType].ToString() == countZoneType)
			{
				if (!string.IsNullOrEmpty(tbBarThresGreen.Text) && !string.IsNullOrEmpty(tbBarThresOrange.Text) && !string.IsNullOrEmpty(tbBarThresRed.Text) && !string.IsNullOrEmpty(tbZoneName.Text) && !string.IsNullOrEmpty(tbEditPeopleCount.Text))
				{
					query = $"UPDATE zones SET name = '{tbZoneName.Text}', threshold_green = '{tbBarThresGreen.Text}', threshold_orange = '{tbBarThresOrange.Text}', threshold_red = '{tbBarThresRed.Text}', people_count='{tbEditPeopleCount.Text}' WHERE id = '{Session["activeZoneID"]}';";
				}
				else
				{
					// Message: not all fields are filled
				}
			}
			else if (Session[activeZoneType].ToString() == accessZoneType)
			{
				if (!string.IsNullOrEmpty(tbZoneName.Text))
				{
					query = $"UPDATE zones SET name = '{tbZoneName.Text}'";

					foreach (string right in badgeRights)
					{
						CheckBox checkBox = (CheckBox) FindControl("cb" + right);
						query += $", {right} = {Convert.ToInt16(checkBox.Checked)}";
					}
				}
				else
				{
					// Message: not all fields are filled
				}
				query += $" WHERE id = '{Session["activeZoneID"]}';";
			}

			try
			{
				conn.Open();
				MySqlCommand cmd = new MySqlCommand(query, conn);
				cmd.ExecuteNonQuery();
				conn.Close();
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}
			LoadZonePanel();
		}

		protected void cbBarLock_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				string query = $"UPDATE zones SET barometer_lock = '{Convert.ToInt16(cbBarLock.Checked)}' WHERE id = '{Session["activeZoneID"]}';";
				conn.Open();
				MySqlCommand cmd = new MySqlCommand(query, conn);
				cmd.ExecuteNonQuery();
				conn.Close();

				// MQTT: barometer update
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}
			LoadZonePanel();
		}

		protected void cbAccessLock_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				string query = $"UPDATE zones SET access_lock = '{Convert.ToInt16(cbAccessLock.Checked)}' WHERE id = '{Session["activeZoneID"]}';";
				conn.Open();
				MySqlCommand cmd = new MySqlCommand(query, conn);
				cmd.ExecuteNonQuery();
				conn.Close();

				// MQTT: access update
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}
			LoadZonePanel();
		}

		protected void barManChange_Click(object sender, EventArgs e)
		{
			Button btnBarMan = (Button) sender;
			try
			{
				string query = $"UPDATE zones SET barometer_color = '{btnBarMan.Attributes["data-color"]}' WHERE id = '{Session["activeZoneID"]}';";
				conn.Open();
				MySqlCommand cmd = new MySqlCommand(query, conn);
				cmd.ExecuteNonQuery();
				conn.Close();

				// MQTT: barometer update
			}
			catch (Exception ex)
			{
				// Message: connection with db lost
			}
			LoadZonePanel();
		}

		protected void dbZoneLogbookFilter_SelectedIndexChanged(object sender, EventArgs e)
		{
			LoadZonePanel();
		}
	}
}