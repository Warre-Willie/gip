﻿using System;

namespace crowd_management.pages
{
    public partial class rapport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}