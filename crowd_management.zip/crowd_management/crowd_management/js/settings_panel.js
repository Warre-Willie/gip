function toggleSettings() {
    var divInfoPanel = document.getElementById("divInfoPanel");
    var divSettingsPanel = document.getElementById("divSettingsPanel");

    divInfoPanel.classList.toggle("hide");
    divSettingsPanel.classList.toggle("hide");
}
